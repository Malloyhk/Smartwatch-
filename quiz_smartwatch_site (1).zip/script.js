const form = document.getElementById('quiz-form');
const quiz = document.getElementById('quiz');
const roleta = document.getElementById('roleta');
const girarBtn = document.getElementById('girar');
const mensagem = document.getElementById('mensagem');

let tentativa = 0;

form?.addEventListener('submit', function (e) {
  e.preventDefault();
  quiz.classList.add('hidden');
  roleta.classList.remove('hidden');
});

girarBtn?.addEventListener('click', () => {
  tentativa++;
  girarBtn.disabled = true;
  mensagem.textContent = 'Girando...';

  setTimeout(() => {
    if (tentativa === 1) {
      mensagem.textContent = 'Não foi dessa vez! Tente novamente.';
      girarBtn.disabled = false;
    } else {
      mensagem.innerHTML = `
        🎉 Você ganhou um Smartwatch!<br><br>
        <a href="checkout.html" style="color: #00b894; font-weight: bold;">Clique aqui para confirmar e pagar o frete</a>
      `;
    }
  }, 3000);
});